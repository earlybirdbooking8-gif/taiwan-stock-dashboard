# Project Rules

## CI/CD 自動化發布流程 (Deployment Pipeline)
完成每項功能後，必須依照以下 6 個步驟自動執行：

【第一步：執行測試】
- 執行所有本地測試。
- 若測試失敗：修正錯誤 -> 重新測試 -> 測試全部通過才能繼續。

【第二步：同步 GitHub】
- `git add .`
- 撰寫有意義的 Commit Message (遵循下方規範)
- `git commit`
- `git push origin main`

【第三步：建立 Production Build】
- 準備發布所需的最終版本檔案。

【第四步：打包成 ZIP】
- 將 Production Build 壓縮為 `taiwan-stock-dashboard.zip`（需排除 `.venv`, `.git`, `__pycache__` 等不必要檔案）。

【第五步：自動部署至 mite.now】
- 啟動 Browser Automation 自動登入 `mite.now`。
- 拖曳 `taiwan-stock-dashboard.zip` 至上傳區，等待上傳完成。
- 輸入 API Key 並完成 Deploy。

【第六步：驗證與回報】
- 確認網站可正常開啟。
- 若部署失敗，分析原因並重新部署直到成功。
- 最後必須回傳：1. Git Commit Hash 2. GitHub Push 成功 3. mite.now 網址 4. Deployment Status。

- **核心原則**：GitHub Repository 為唯一正式版本（Single Source of Truth）。未測試成功不得 Push。任何程式修改都必須先修改本地專案，通過測試後自動觸發上述流程。

## Commit Message 規範
遵循 Conventional Commits 規範：
- `feat:` 新增功能 (例如: feat: 新增夜盤資料分析)
- `fix:` 修正錯誤 (例如: fix: 修正 PDF 無法下載)
- `refactor:` 重構程式碼 (例如: refactor: 重構資料同步模組)
- `style:` 程式碼格式調整
- `docs:` 說明文件更新
- `test:` 測試相關
- `chore:` 雜項、建置工具等更新

## Branching 規範
任何重大修改請先建立新 Branch，經確認後再合併到 main：
- `feature/*`
- `bugfix/*`
- `hotfix/*`
